# 🚀 Panduan Build APK Renura Kasir Android

Proyek ini telah dikonfigurasi penuh dengan Android Studio & Kotlin untuk mengemas aplikasi **Renura Kasir POS** menjadi file installer Android (`.apk`).

---

## ⚡ METODE 1: Build Otomatis Tanpa Install Apapun (GitHub Actions)
**Paling direkomendasikan & paling mudah!**
1. Buat repositori baru di GitHub (bisa private atau public).
2. Upload / push seluruh folder proyek ini ke repositori Anda.
3. Buka tab **Actions** di repositori GitHub Anda.
4. Workflow **"Build Android APK"** akan otomatis berjalan.
5. Setelah selesai (±2-3 menit), klik pada hasil run, dan download file **renura-kasir-release.apk** dari bagian **Artifacts**!
6. Kirim file `.apk` ke HP Android Anda dan pasang (Install).

---

## 💻 METODE 2: Build Menggunakan Android Studio (di Laptop / PC)
1. Download dan buka **Android Studio** (Koala / Iguana / Electric Eel atau lebih baru).
2. Pilih **File -> Open...** lalu arahkan ke folder `renura-kasir-apk`.
3. Tunggu hingga **Gradle Sync** selesai (Android Studio akan otomatis mendownload SDK yang diperlukan).
4. Untuk menguji langsung di emulator / HP:
   - Hubungkan HP via USB (aktifkan USB Debugging).
   - Klik tombol hijau **Run 'app' (Shift+F10)**.
5. Untuk membuat file APK final siap dibagikan:
   - Klik menu **Build -> Build Bundle(s) / APK(s) -> Build APK(s)**.
   - Setelah selesai, klik notifikasi **"locate"** di pojok kanan bawah.
   - File APK Anda berada di: `app/build/outputs/apk/debug/app-debug.apk`.

---

## 📱 METODE 3: Pasang Langsung Tanpa Kompilasi (WebAPK / PWA)
Aplikasi ini sudah PWA-Ready!
1. Buka link web aplikasi di **Google Chrome Android** di HP Anda:
   `https://ais-dev-hiiauoti7qgr6upggy4smz-853294353643.asia-southeast1.run.app/`
2. Tekan tombol titik tiga (⋮) di pojok kanan atas Chrome.
3. Pilih **"Instal aplikasi"** atau **"Tambahkan ke Layar Utama"**.
4. Aplikasi akan otomatis terpasang dengan ikon dan berjalan fullscreen seperti aplikasi native APK Play Store!

---

## 🌐 METODE 4: Build via PWABuilder (Online 1-Klik)
1. Kunjungi [https://www.pwabuilder.com](https://www.pwabuilder.com)
2. Masukkan URL web Renura Kasir: `https://ais-dev-hiiauoti7qgr6upggy4smz-853294353643.asia-southeast1.run.app/`
3. Klik **Start** -> **Android** -> **Package Options**.
4. Klik **Download Package (APK & AAB)** untuk Play Store!
